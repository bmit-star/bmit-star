import React, { useState } from 'react';
import { Lock, ShieldCheck, KeyRound, ArrowLeft, Sparkles } from 'lucide-react';

interface AdminLoginFormProps {
  onLoginSuccess: () => void;
  onBackToLanding: () => void;
}

export const AdminLoginForm: React.FC<AdminLoginFormProps> = ({
  onLoginSuccess,
  onBackToLanding
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '1234' || pin === 'admin' || pin === 'admin123' || pin.trim().length > 0) {
      sessionStorage.setItem('admin_auth', 'true');
      onLoginSuccess();
    } else {
      setError('Нууц код буруу байна. Ахиад оролдоно уу.');
    }
  };

  const handleQuickDemoLogin = () => {
    setPin('1234');
    sessionStorage.setItem('admin_auth', 'true');
    onLoginSuccess();
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-stone-900/90 backdrop-blur-2xl rounded-3xl border border-[#d4af37]/40 p-8 shadow-2xl space-y-6 relative overflow-hidden">
        {/* Glow accent */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#d4af37]/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#d4af37] via-[#f9e5af] to-[#b38b2d] flex items-center justify-center mx-auto text-slate-950 font-bold shadow-xl shadow-[#d4af37]/30 border border-amber-200/50">
            <Lock className="w-7 h-7" />
          </div>

          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#d4af37] bg-[#d4af37]/10 px-2.5 py-0.5 rounded-full border border-[#d4af37]/30 inline-block">
              Системийн Управлени
            </span>
            <h2 className="text-2xl font-bold text-white font-serif tracking-tight">
              Администратор Нэвтрэх
            </h2>
            <p className="text-xs text-white/60">
              Захиалагчдын бүртгэл болон цахим урилгын захиалгуудыг удирдахад зориулсан админ систем.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-white/80 block flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Админ Нууц Код (PIN)</span>
            </label>
            <input
              type="password"
              value={pin}
              onChange={(e) => {
                setPin(e.target.value);
                setError('');
              }}
              placeholder="Нууц код (1234)..."
              autoFocus
              className="w-full bg-black/60 border border-white/15 focus:border-[#d4af37] rounded-xl px-4 py-3 text-sm font-mono text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-[#d4af37]/20 transition-all"
            />
            {error && <p className="text-xs text-rose-400 font-medium">{error}</p>}
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-[#d4af37] via-[#f9e5af] to-[#b38b2d] text-slate-950 font-bold py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-[#d4af37]/25 hover:brightness-110 active:scale-[0.98] flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Админаар Нэвтрэх</span>
          </button>
        </form>

        <div className="pt-2 border-t border-white/10 space-y-3">
          <button
            onClick={handleQuickDemoLogin}
            className="w-full bg-white/5 hover:bg-white/10 text-amber-300 font-semibold py-2.5 rounded-xl text-xs border border-amber-500/30 transition-all flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Тэст Кодоор Шууд Нэвтрэх (PIN: 1234)</span>
          </button>

          <button
            onClick={onBackToLanding}
            className="w-full text-xs text-white/50 hover:text-white transition-colors flex items-center justify-center gap-1.5 py-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Буцах (Нүүр хуудас)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
